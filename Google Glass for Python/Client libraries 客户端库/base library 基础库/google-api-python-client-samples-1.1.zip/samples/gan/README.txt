Python Sample Code for the Google Affiliate Network APIs
--------------------------------------------------------
See API docs at https://code.google.com/apis/gan/index.html
for system/dependency requirements and more information.
